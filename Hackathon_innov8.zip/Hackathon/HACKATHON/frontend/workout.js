function strength1() {
    window.open('https://youtu.be/9FBIaqr7TjQ?si=Af2ENH_fZ6yNBsLj', '_blank');
  }
  function strength2() {
    window.open('https://youtu.be/tj0o8aH9vJw?si=yKAjajwpKpTgDLkI', '_blank');
  }

  function strength3() {
    window.open('https://youtu.be/0hYDDsRjwks?si=vyMr5VjnsDlACT6T', '_blank');
  }
  function strength4() {
    window.open('https://youtu.be/jeLxN-wt7jY?si=zittcJFB7iqdURdl', '_blank');
  }
  function warmup1() {
    window.open('https://youtu.be/vWiu6ayDo2A?si=9Y2SOPc9QKC5rFb-', '_blank');
  }
  function meditation1(){
    window.open('https://youtu.be/fgChzlOt3XI?si=MQrVr6nqVykOKRzq', '_blank')
  }
  function nutrition1(){
    window.open('https://youtu.be/CxbBQar9les?si=A09P8cuKIXW0pMvi', '_blank')
  }